import React from 'react';
import ReactDOM from 'react-dom';
import DisplayComponent from './components/MainDisplayComponent';


ReactDOM.render(<DisplayComponent/>, document.getElementById('app'));