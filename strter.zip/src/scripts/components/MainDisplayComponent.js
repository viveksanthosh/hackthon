'use strict';

import React from 'react';
import Hello from './Hello';
export default class Display extends React.Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <Hello message="Welcome"/>
        );
    }
}

