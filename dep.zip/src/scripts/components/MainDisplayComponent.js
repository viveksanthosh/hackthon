'use strict';

import React from 'react';
import Hello from './Hello';
export default class Display extends React.Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div class="row">
 <span className="col-xs-1">
<p className="glyphicon glyphicon-star-empty" style={{"font-size": "40px"}}></p>
</span>
 <span className="col-xs-1">
<p className="glyphicon glyphicon-star-empty" style={{"font-size": "40px"}}></p>
</span> <span className="col-xs-1">
<p className="glyphicon glyphicon-star-empty" style={{"font-size": "40px"}}></p>
</span> <span className="col-xs-1">
<p className="glyphicon glyphicon-star-empty" style={{"font-size": "40px"}}></p>
</span>
 <span className="col-xs-1">
<p className="glyphicon glyphicon-star-empty" style={{"font-size": "40px"}}></p>
</span>
            </div>

        );
    }
}

